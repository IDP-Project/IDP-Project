python project-ui.py > log.txt
python check.py >> log.txt

python project-ui.py
python check.py
